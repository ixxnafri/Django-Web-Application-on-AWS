import React, {PureComponent} from 'react';
import Avatar from 'material-ui/Avatar';
class avatar extends PureComponent {
    render(){
    }
}